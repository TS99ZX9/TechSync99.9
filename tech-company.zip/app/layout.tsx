import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { AssistantProvider } from "@/components/ai-assistant/ai-assistant-provider"
import { AIAssistant } from "@/components/ai-assistant/ai-assistant"
import { AIPageGuide } from "@/components/ai-assistant/ai-page-guide"
import { DynamicBackground } from "@/components/ai-assistant/dynamic-background"

const inter = Inter({ subsets: ["latin"] })

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
          <AssistantProvider>
            <DynamicBackground />
            {children}
            <AIAssistant />
            <AIPageGuide />
          </AssistantProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'

export const metadata = {
      generator: 'v0.dev'
    };
