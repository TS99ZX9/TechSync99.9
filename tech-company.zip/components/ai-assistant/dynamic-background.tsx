"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { getEngagementLevel } from "@/utils/animation-utils"

export function DynamicBackground() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [engagementLevel, setEngagementLevel] = useState("medium")

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({
        x: e.clientX / window.innerWidth,
        y: e.clientY / window.innerHeight,
      })
    }

    // Update engagement level every 2 seconds
    const engagementInterval = setInterval(() => {
      setEngagementLevel(getEngagementLevel())
    }, 2000)

    window.addEventListener("mousemove", handleMouseMove)

    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
      clearInterval(engagementInterval)
    }
  }, [])

  // Calculate movement intensity based on engagement level
  const getMovementIntensity = () => {
    switch (engagementLevel) {
      case "high":
        return 30
      case "medium":
        return 20
      case "low":
        return 10
      default:
        return 20
    }
  }

  const intensity = getMovementIntensity()

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {/* Red gradient blob that follows mouse */}
      <motion.div
        className="absolute w-[600px] h-[600px] rounded-full bg-red-500/5 blur-[100px]"
        animate={{
          x: mousePosition.x * intensity - intensity / 2,
          y: mousePosition.y * intensity - intensity / 2,
        }}
        transition={{
          type: "spring",
          damping: 30,
          stiffness: 50,
        }}
        style={{
          left: "30%",
          top: "30%",
        }}
      />

      {/* Black gradient blob that moves opposite to mouse */}
      <motion.div
        className="absolute w-[500px] h-[500px] rounded-full bg-black/20 blur-[80px]"
        animate={{
          x: (-mousePosition.x * intensity) / 2,
          y: (-mousePosition.y * intensity) / 2,
        }}
        transition={{
          type: "spring",
          damping: 40,
          stiffness: 40,
        }}
        style={{
          right: "25%",
          bottom: "25%",
        }}
      />
    </div>
  )
}

